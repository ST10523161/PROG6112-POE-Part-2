/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.wildlife.rescue;

import static org.testng.Assert.*;

/**
 *
 * @author motso
 */
public class RescueStatusNGTest {
    
    public RescueStatusNGTest() {
    }

    @org.testng.annotations.Test
    public void testSomeMethod() {
    }
    
}
