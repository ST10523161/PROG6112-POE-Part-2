/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/EmptyTestNGTest.java to edit this template
 */
package com.mycompany.wildlife.rescue;

import static org.testng.Assert.*;
import org.testng.annotations.Test;

/**
 *
 * @author motso
 */
public class RescuePriorityNGTest {
    
    public RescuePriorityNGTest() {
    }

    @Test
    public void testSomeMethod() {
    }
    
}
